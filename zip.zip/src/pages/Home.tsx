import { Hero } from "@/components/hero/Hero";
import { LogoSlider } from "@/components/logo-slider/LogoSlider";
import { Features } from "@/components/features/Features";
import { Pricing } from "@/components/pricing/Pricing";
import { HowItWorks } from "@/components/how-it-works/HowItWorks";
import { Faq } from "@/components/faq/Faq";
import { Cta } from "@/components/cta/Cta";

export default function Home() {
  return (
    <>
      <Hero />
      <LogoSlider />
      <Features />
      <Pricing />
      <HowItWorks />
      <Faq />
      <Cta />
    </>
  );
}
