import { Bot, Globe, SlidersHorizontal, TrendingUp } from "lucide-react";
import type { FeatureItem } from "@/types";

export const FEATURES: FeatureItem[] = [
  {
    icon: Bot,
    title: "AI-Powered Replies",
    description: "Uses advanced AI to generate smart, human-like replies.",
  },
  {
    icon: Globe,
    title: "Works Everywhere",
    description: "AutoReply AI works on any website, any platform.",
  },
  {
    icon: SlidersHorizontal,
    title: "Custom Rules",
    description: "Set your own rules, keywords, and reply preferences.",
  },
  {
    icon: TrendingUp,
    title: "Boost Engagement",
    description: "Respond instantly, engage more, and grow faster.",
  },
];
