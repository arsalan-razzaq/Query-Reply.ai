import type { PricingPlan } from "@/types";

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "free",
    name: "Free",
    description: "Get started at no cost",
    price: 0,
    period: "month",
    badge: "Free Forever",
    features: [
      "Auto reply on any website",
      "AI-powered smart replies",
      "Up to 3 replies per conversation",
      "Basic settings",
    ],
    ctaLabel: "Get Started Free",
  },
  {
    id: "monthly",
    name: "Monthly",
    description: "Perfect for short-term users",
    price: 5,
    originalPrice: 10,
    period: "month",
    badge: "Most Popular",
    discountLabel: "Launch Offer — 50% OFF",
    highlight: true,
    features: [
      "All Free plan features",
      "Unlimited auto replies",
      "Custom reply rules",
      "Priority support",
      "Advanced AI responses",
    ],
    ctaLabel: "Get Monthly Plan",
  },
  {
    id: "yearly",
    name: "Yearly",
    description: "Best value for long-term users",
    price: 100,
    period: "year",
    badge: "Save 17%",
    features: [
      "All Monthly plan features",
      "Unlimited auto replies",
      "Custom reply rules",
      "Priority support",
      "Early access to new features",
    ],
    ctaLabel: "Get Yearly Plan",
  },
];
