import type { FooterLinkGroup, SocialLink } from "@/types";
import {
  XSocialIcon,
  LinkedInSocialIcon,
  InstagramSocialIcon,
  FacebookSocialIcon,
} from "@/components/common/SocialIcons";

export const FOOTER_LINK_GROUPS: FooterLinkGroup[] = [
  {
    title: "Quick Links",
    links: [
      { label: "Home", href: "#home" },
      { label: "Features", href: "#features" },
      { label: "How It Works", href: "#how-it-works" },
      { label: "Pricing", href: "#pricing" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Documentation", href: "#" },
      { label: "Blog", href: "#" },
      { label: "Support Center", href: "#" },
      { label: "Privacy Policy", href: "#" },
      { label: "Terms of Service", href: "#" },
    ],
  },
];

export const SOCIAL_LINKS: SocialLink[] = [
  { label: "X (Twitter)", href: "#", icon: XSocialIcon },
  { label: "LinkedIn", href: "#", icon: LinkedInSocialIcon },
  { label: "Instagram", href: "#", icon: InstagramSocialIcon },
  { label: "Facebook", href: "#", icon: FacebookSocialIcon },
];
