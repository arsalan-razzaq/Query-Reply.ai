export const SITE = {
  name: "AutoReply AI",
  tagline: "Never Miss a Message. Always Reply.",
  description:
    "AutoReply AI is your smart browser extension that automatically replies to messages on any website using AI. Save time, stay responsive, and grow your business effortlessly.",
  url: "https://autoreply.ai",
} as const;
