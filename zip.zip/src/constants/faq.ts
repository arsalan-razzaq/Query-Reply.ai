import type { FaqItem } from "@/types";

export const FAQS: FaqItem[] = [
  {
    question: "What is AutoReply AI?",
    answer:
      "AutoReply AI is a browser extension that uses artificial intelligence to automatically reply to messages on any website, so you never miss a conversation.",
  },
  {
    question: "Which platforms does it work on?",
    answer:
      "AutoReply AI works on virtually any website with a chat or messaging interface, including WhatsApp Web, Telegram, Messenger, Instagram, Slack, Gmail, and many marketplace platforms.",
  },
  {
    question: "Do I need coding skills to set it up?",
    answer:
      "Not at all. Just install the extension, configure your reply preferences in a few clicks, and AutoReply AI takes care of the rest.",
  },
  {
    question: "Can I customize the AI's replies?",
    answer:
      "Yes. You can set custom prompts, reply rules, and keywords so the AI matches your tone and business needs.",
  },
  {
    question: "Is there a free plan?",
    answer:
      "Yes, the Free plan lets you try AutoReply AI at no cost with up to 3 replies per conversation, plus a 3-day trial of premium features.",
  },
  {
    question: "Can I cancel my subscription anytime?",
    answer:
      "Absolutely. You can upgrade, downgrade, or cancel your plan at any time from your account settings, no questions asked.",
  },
];
