import { Hash, Inbox, UserSquare, Users, ShoppingBag } from "lucide-react";
import {
  WhatsAppIcon,
  TelegramIcon,
  MessengerIcon,
  InstagramIcon,
  DiscordIcon,
  GmailIcon,
  XBrandIcon,
  GoogleChatIcon,
  AlibabaIcon,
  FiverrIcon,
  UpworkIcon,
  G2GIcon,
  FacebookIcon,
} from "@/components/common/BrandIcons";
import type { IntegrationLogo } from "@/types";

export const INTEGRATIONS: (IntegrationLogo & { color: string })[] = [
  { name: "WhatsApp", icon: WhatsAppIcon, color: "#25D366" },
  { name: "Telegram", icon: TelegramIcon, color: "#26A5E4" },
  { name: "Messenger", icon: MessengerIcon, color: "#0866FF" },
  { name: "Instagram", icon: InstagramIcon, color: "#FF0069" },
  { name: "Discord", icon: DiscordIcon, color: "#5865F2" },
  // No official mark available from our icon source — generic glyph in brand color.
  { name: "Slack", icon: Hash, color: "#611F69" },
  { name: "Gmail", icon: GmailIcon, color: "#EA4335" },
  { name: "Outlook", icon: Inbox, color: "#0078D4" },
  { name: "LinkedIn", icon: UserSquare, color: "#0A66C2" },
  { name: "X (Twitter)", icon: XBrandIcon, color: "#000000" },
  { name: "Google Chat", icon: GoogleChatIcon, color: "#34A853" },
  { name: "Microsoft Teams", icon: Users, color: "#6264A7" },
  { name: "OLX", icon: ShoppingBag, color: "#002F34" },
  { name: "Alibaba", icon: AlibabaIcon, color: "#FF6A00" },
  { name: "Fiverr", icon: FiverrIcon, color: "#1DBF73" },
  { name: "Upwork", icon: UpworkIcon, color: "#6FDA44" },
  { name: "G2G", icon: G2GIcon, color: "#ED1C24" },
  { name: "Facebook Marketplace", icon: FacebookIcon, color: "#0866FF" },
];
