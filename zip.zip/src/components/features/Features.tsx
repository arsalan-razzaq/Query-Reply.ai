import { Container } from "@/components/common/Container";
import { SectionHeading } from "@/components/common/SectionHeading";
import { FeatureCard } from "@/components/features/FeatureCard";
import { FEATURES } from "@/constants/features";

export function Features() {
  return (
    <section id="features" className="bg-background py-24 sm:py-32">
      <Container>
        <SectionHeading
          eyebrow="Features"
          title="Everything You Need to Automate Replies"
          description="Built to save you time and help you focus on what matters."
        />

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature, index) => (
            <FeatureCard key={feature.title} feature={feature} index={index} />
          ))}
        </div>
      </Container>
    </section>
  );
}
