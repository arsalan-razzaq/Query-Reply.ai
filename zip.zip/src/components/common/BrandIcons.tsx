import {
  siWhatsapp,
  siTelegram,
  siMessenger,
  siInstagram,
  siDiscord,
  siGmail,
  siX,
  siGooglechat,
  siAlibabadotcom,
  siFiverr,
  siUpwork,
  siG2g,
  siFacebook,
} from "simple-icons";

interface IconProps {
  className?: string;
}

function createBrandIcon(icon: { path: string; title: string }) {
  return function BrandIcon({ className }: IconProps) {
    return (
      <svg
        role="img"
        viewBox="0 0 24 24"
        fill="currentColor"
        className={className}
        aria-label={icon.title}
      >
        <path d={icon.path} />
      </svg>
    );
  };
}

export const WhatsAppIcon = createBrandIcon(siWhatsapp);
export const TelegramIcon = createBrandIcon(siTelegram);
export const MessengerIcon = createBrandIcon(siMessenger);
export const InstagramIcon = createBrandIcon(siInstagram);
export const DiscordIcon = createBrandIcon(siDiscord);
export const GmailIcon = createBrandIcon(siGmail);
export const XBrandIcon = createBrandIcon(siX);
export const GoogleChatIcon = createBrandIcon(siGooglechat);
export const AlibabaIcon = createBrandIcon(siAlibabadotcom);
export const FiverrIcon = createBrandIcon(siFiverr);
export const UpworkIcon = createBrandIcon(siUpwork);
export const G2GIcon = createBrandIcon(siG2g);
export const FacebookIcon = createBrandIcon(siFacebook);
