import { MessageCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { SITE } from "@/constants/site";

interface LogoProps {
  className?: string;
  light?: boolean;
}

export function Logo({ className, light }: LogoProps) {
  return (
    <a
      href="#home"
      className={cn("flex items-center gap-2 font-semibold tracking-tight", className)}
    >
      <span className="bg-gradient-brand flex size-8 items-center justify-center rounded-lg text-white shadow-md shadow-primary/30">
        <MessageCircle className="size-4.5" strokeWidth={2.5} />
      </span>
      <span className={cn("text-lg", light ? "text-white" : "text-foreground")}>
        {SITE.name}
      </span>
    </a>
  );
}
