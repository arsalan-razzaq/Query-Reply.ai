import { motion } from "framer-motion";
import { MessageCircle, LayoutDashboard, Settings } from "lucide-react";

export function DashboardMockup() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.7, ease: "easeOut", delay: 0.3 }}
      className="relative mx-auto w-full max-w-lg"
    >
      <div className="absolute -inset-10 -z-10 rounded-[3rem] bg-brand-violet/20 blur-[80px]" />

      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] shadow-2xl shadow-black/40 backdrop-blur-sm">
        <div className="flex items-center gap-1.5 border-b border-white/10 bg-white/5 px-4 py-3">
          <span className="size-2.5 rounded-full bg-red-400/70" />
          <span className="size-2.5 rounded-full bg-yellow-400/70" />
          <span className="size-2.5 rounded-full bg-green-400/70" />
        </div>
        <div className="space-y-3 p-6">
          <div className="h-3 w-2/3 rounded-full bg-white/10" />
          <div className="h-3 w-1/2 rounded-full bg-white/10" />
          <div className="mt-6 h-24 w-full rounded-xl bg-white/5" />
          <div className="h-3 w-4/5 rounded-full bg-white/10" />
          <div className="h-3 w-3/5 rounded-full bg-white/10" />
        </div>
      </div>

      <motion.div
        animate={{ y: [0, -14, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -right-6 top-10 w-64 rounded-2xl border border-white/10 bg-brand-ink/90 p-4 shadow-2xl shadow-black/50 backdrop-blur-xl sm:-right-10 sm:w-72"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <span className="bg-gradient-brand flex size-6 items-center justify-center rounded-md">
              <MessageCircle className="size-3.5 text-white" />
            </span>
            AutoReply AI
          </div>
          <span className="relative flex size-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
            <span className="relative inline-flex size-2.5 rounded-full bg-green-400" />
          </span>
        </div>

        <div className="mt-4 space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-white/50">Status</span>
            <span className="font-medium text-green-400">Active</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-white/50">Auto Reply</span>
            <span className="flex h-4 w-8 items-center rounded-full bg-brand-violet p-0.5">
              <span className="size-3 translate-x-4 rounded-full bg-white transition-transform" />
            </span>
          </div>
          <div>
            <span className="text-white/50">Reply Mode</span>
            <div className="mt-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-white/80">
              AI Smart Reply
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between text-white/50">
              <span>Reply Count</span>
              <span>3 / 3 used</span>
            </div>
            <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
              <div className="bg-gradient-brand h-full w-full rounded-full" />
            </div>
          </div>
          <button
            type="button"
            className="bg-gradient-brand w-full rounded-lg py-2 text-center text-xs font-semibold text-white shadow-md shadow-primary/30"
          >
            Save Settings
          </button>
          <div className="flex items-center justify-between border-t border-white/10 pt-3 text-white/50">
            <span className="flex items-center gap-1.5">
              <LayoutDashboard className="size-3.5" /> Dashboard
            </span>
            <span className="flex items-center gap-1.5">
              <Settings className="size-3.5" /> Settings
            </span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
