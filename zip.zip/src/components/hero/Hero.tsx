import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, PlayCircle, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container } from "@/components/common/Container";
import { HeroBackground } from "@/components/hero/HeroBackground";
import { DashboardMockup } from "@/components/hero/DashboardMockup";
import { SITE } from "@/constants/site";
import { scrollToHash } from "@/utils/scroll";

const HIGHLIGHTS = [
  "Works on any website",
  "Custom reply rules",
  "AI-Powered smart replies",
  "Increase engagement",
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" as const, delay },
  }),
};

export function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden bg-brand-ink pt-32 pb-24 sm:pt-40 sm:pb-32"
    >
      <HeroBackground />

      <Container className="relative grid items-center gap-16 lg:grid-cols-2 lg:gap-12">
        <div className="text-center lg:text-left">
          <motion.div
            initial="hidden"
            animate="show"
            variants={fadeUp}
            custom={0}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-white/80 backdrop-blur-sm"
          >
            <span className="bg-gradient-brand size-1.5 rounded-full" />
            AI-Powered Auto Reply Extension
          </motion.div>

          <motion.h1
            initial="hidden"
            animate="show"
            variants={fadeUp}
            custom={0.1}
            className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl"
          >
            Never Miss a Message.
            <br />
            <span className="text-gradient">Always Reply.</span>
          </motion.h1>

          <motion.p
            initial="hidden"
            animate="show"
            variants={fadeUp}
            custom={0.2}
            className="mx-auto mt-6 max-w-xl text-base text-white/60 sm:text-lg lg:mx-0"
          >
            {SITE.description}
          </motion.p>

          <motion.ul
            initial="hidden"
            animate="show"
            variants={fadeUp}
            custom={0.3}
            className="mx-auto mt-8 grid max-w-md grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-2 lg:mx-0"
          >
            {HIGHLIGHTS.map((item) => (
              <li key={item} className="flex items-center gap-2 text-sm text-white/70">
                <CheckCircle2 className="size-4 shrink-0 text-brand-violet" />
                {item}
              </li>
            ))}
          </motion.ul>

          <motion.div
            initial="hidden"
            animate="show"
            variants={fadeUp}
            custom={0.4}
            className="mt-10 flex flex-col items-center gap-4 sm:flex-row lg:justify-start"
          >
            <Button
              size="lg"
              onClick={() => scrollToHash("#pricing")}
              className="bg-gradient-brand group h-12 w-full rounded-xl px-7 text-base font-semibold text-white shadow-lg shadow-primary/30 transition-transform hover:scale-[1.02] hover:opacity-95 sm:w-auto"
            >
              Get Started Free
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollToHash("#how-it-works")}
              className="h-12 w-full rounded-xl border-white/15 bg-white/5 px-7 text-base font-semibold text-white hover:bg-white/10 hover:text-white sm:w-auto"
            >
              <PlayCircle className="size-4" />
              See How It Works
            </Button>
          </motion.div>

          <motion.p
            initial="hidden"
            animate="show"
            variants={fadeUp}
            custom={0.5}
            className="mt-5 flex items-center justify-center gap-1.5 text-xs text-white/40 lg:justify-start"
          >
            <ShieldCheck className="size-3.5" />
            No credit card required
          </motion.p>
        </div>

        <DashboardMockup />
      </Container>
    </section>
  );
}
